BHIM PDF VIEWER — STARTER PROJECT

IMPORTANT:
1) index.html is a visual/demo website and can be opened directly in a browser.
2) It does NOT yet connect to an online shared database or online file storage.
3) To make visitor records and admin uploads shared across devices, configure Firebase and use the Firebase-connected files in this project.
4) Name + roll number is not secure identity verification. Do not upload private or sensitive documents to a public-read demo.
5) Hiding print/download controls cannot prevent screenshots or other copying.

LOCAL TEST:
- Extract this ZIP.
- Double-click index.html.
- Test the demo in Chrome/Edge.

ONLINE HOSTING:
- Upload the files to a GitHub repository.
- GitHub repository -> Settings -> Pages -> Deploy from branch -> main -> /(root).
- This static hosting step only hosts the front-end; it does not create online database/storage by itself.

Firebase connection must be configured separately before using real online uploads, authentication and visitor logs.
